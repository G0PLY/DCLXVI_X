#pragma once
void randombytes_ctrrandom_init();
