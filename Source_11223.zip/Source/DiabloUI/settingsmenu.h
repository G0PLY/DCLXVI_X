#pragma once

#include "DiabloUI/diabloui.h"

namespace devilution {

void UiSettingsMenu();

} // namespace devilution
