#pragma once

namespace devilution {

bool UiSelHeroYesNoDialog(const char *title, const char *body);

} // namespace devilution
