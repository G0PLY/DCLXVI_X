#include <cstddef>

namespace devilution {

extern const char *const SupportLines[];
extern const std::size_t SupportLinesSize;

} // namespace devilution
