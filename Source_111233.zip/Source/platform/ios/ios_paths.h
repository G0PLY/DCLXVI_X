#pragma once

#ifdef __cplusplus
extern "C" {
#endif

extern char *IOSGetPrefPath();

#ifdef __cplusplus
}
#endif
