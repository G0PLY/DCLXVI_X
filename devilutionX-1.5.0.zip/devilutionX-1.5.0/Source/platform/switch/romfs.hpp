#pragma once
void switch_romfs_init();
