#pragma once
void randombytes_switchrandom_init();
