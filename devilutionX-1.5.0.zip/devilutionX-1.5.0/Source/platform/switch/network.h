#pragma once

void switch_enable_network();
void switch_disable_network();
