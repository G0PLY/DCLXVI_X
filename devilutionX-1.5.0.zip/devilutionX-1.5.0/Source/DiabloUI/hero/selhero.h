#pragma once

#include <cstdint>

namespace devilution {

extern bool selhero_isMultiPlayer;
extern bool selhero_endMenu;

void selhero_Init();
void selhero_List_Init();

} // namespace devilution
