# DevilutionX OpenDingux Port

See docs/building.md for build instructions.
