devilutionx(Diablo port) for MiniUI
====================================

Installation
--------
- Copy this folder onto your SD card in the location /Roms/Native Games (SH)/

For the full game:
  - Get the DIABDAT.MPQ from either the CD or GOG release (https://github.com/diasurgical/devilutionX/wiki/Extracting-the-.MPQs-from-the-GoG-installer)
  - Copy the DIABDAT.MPQ into this folder
  - Optional: If you want to also play the Hellfire expansion, copy hellfire.mpq, hfmonk.mpq, hfmusic.mpq, hfvoice.mpq into this fodler aswell

For the free shareware version:
  - Get the spawn.mpq (https://github.com/diasurgical/devilutionx-assets/releases/download/v2/spawn.mpq)
  - Copy the spawn.mpq into this folder

Controls
--------
- D-Pad: move
- A: Attack nearest enemy, talk to NPC, pickup/place in inventory, OK in menus
- B: select spell, back in menus
- X: pickup items, open chests and doors, use item in inventory
- Y: cast spell, delete character in main menu
- L: use health item from belt
- R: use mana potion from belt
- L2: character panel
- R2: inventory panel
- Menu: game menu

- Start show quick acess overlay
- Start + Up: game menu
- Start + Down: toggle automap
- Start + Left: character sheet
- Start + Right: inventory
- Start + Y: quest log
- Start + B: spell book
- Select + D-Pad: simulate arrow keys
- Select + A;B;X;Y: spell hotkeys
