#pragma once

namespace devilution {

uint32_t GetMillisecondsSinceStartup();

}
