#pragma once

#include_next <netdb.h>

#define EAI_SERVICE -401
#define EAI_AGAIN -402
#define EAI_BADFLAGS -403
#define EAI_FAIL -404
