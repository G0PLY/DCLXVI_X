#pragma once

#include <cstdint>

uint32_t Get3DSScalingFlag(bool fitToScreen, int width, int height);
