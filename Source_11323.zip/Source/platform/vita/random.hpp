#pragma once
void randombytes_vitarandom_init();
