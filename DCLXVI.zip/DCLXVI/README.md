# DCLXVI_X
Diablo mod

Updated from Devilution to DevilutionX...
=======
--------------------------------------------------------------------------------------------------
DCLXVI Beta Version Xb
=======

(You will need a Diablo CD to use this)
=======

Diablo 1 Mod DCLXVI by G0PLY,
made using DevilutionX v1.41 by GalaXyHaXz and Devilution Team.
=======
--------------------------------------------------------------------------------------------------

Prebuilt Version only, for now...

Download DCLXVI.zip

The following files are not included in this download: 
DIABDAT.MPQ diabloui.dll SMACKW32.DLL STANDARD.snp Storm.dll (from Diablo CD)
hellfire.mpq hfmonk.mpq hfmusic.mpq hfvoice.mpq (from Hellfire CD)

drop the files listed above into the following location
({drive}:\Users\{username}\AppData\Roaming\daemonstrat\DCLXVI)
or goto File Explorer and type %AppData%

Digital verion of Diablo plus Hellfire can be purchased at www.gog.com

--------------------------------------------------------------------------------------------------
DCLXVI Features: 
=======
Ironman esk inspired Diablo mod
--------------------------------------------------------------------------------------------------
Added "Classes", class skills may only be used by other classes with scrolls,

Multiplayer mode only,

Weapons may have spells,

Players start with 100gp and no items,

Increased curse chances on items,

Removed most magic type restrictions on items, 

Increased level cap (100, softcap currently 70), 

Reduced stat gain (3 per lv), 

Vitality capped depending on class,

Slight adjustment on starting stats,

Increased stat caps (primary stat still 250), 

Removed free refill of health and mana (leveling up and NPC visits),

Removed elixer potions from shops,

Gris sometimes sells oils in basic tab,

New Charging runes (witch sometimes sells),

New Stat Exchange Uniques (12 rings, 6 amulets),

Removed accuracy and sharpness oils,

Increased monster health, 

Increases monsters per floor,

Modified weapon and armor requirements,

NPC's no longer repair or recharge items,

Must kill Diablo to advance difficulty.

Class Abilities:
Warrior - ItemRepair
Rogue - TrapDisarm
Sorcerer - ManaShield
Monk - Warp
Bard - Berserk
Barbarian - Rage
Paladin - Resurrect
Assassin - Infravision
Battlemage - Teleport
Kabbalist - Golem
Templar - Reflect
Witch - StaffRecharge
Psychokineticist - Telekinesis
Sage - Identify
Warlock - Magi
Traveler - TownPortal
Cleric - HealOther


--------------------------------------------------------------------------------------------------
Using devilutionX-1.41
=======

For more information or more detailed instructions on installing. https://github.com/diasurgical/devilutionX/
=======
--------------------------------------------------------------------------------------------------
