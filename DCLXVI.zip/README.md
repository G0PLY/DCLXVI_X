# DCLXVI_X
Diablo mod

Updated version, more to come (maybe)...
=======
--------------------------------------------------------------------------------------------------
DCLXVI Beta Version Xb
=======

(You will need a Diablo CD to use this)
=======

Diablo 1 DCLXVI Mod by G0PLY,
made using DevilutionX v1.41 by GalaXyHaXz and Devilution Team.
=======
--------------------------------------------------------------------------------------------------

Prebuilt Version only, for now...

Download DCLXVI.zip

The following files are not included in this download: 
DIABDAT.MPQ diabloui.dll SMACKW32.DLL STANDARD.snp Storm.dll (from Diablo CD)
hellfire.mpq hfmonk.mpq hfmusic.mpq hfvoice.mpq (from Hellfire CD)

drop the files listed above into the following location
({drive}:\Users\{username}\AppData\Roaming\daemonstrat\DCLXVI)

Digital verion of Diablo plus Hellfire can be purchased at www.gog.com

--------------------------------------------------------------------------------------------------
DCLXVI Features: 
=======
--------------------------------------------------------------------------------------------------
Added "Classes", class skills may only be used with scrolls by other classes,

Weapons may have spells,

Removed magic property restrictions, 

Increased level cap (100), 

Reduced stat gain (3 per lv), 

Vitality capped depending on class,

Slight adjustment on starting stats,

Increased stat caps (primary stat still 250), 

Increased exp rates, 

Removed free refill of health and mana for leveling up,

Removed elixer potions from shopkeepers listing,

Increased monster difficulty, 

Modified weapon and armor requirements.

--------------------------------------------------------------------------------------------------
Using devilutionX-1.41
=======

For more information or more detailed instructions on installing. https://github.com/diasurgical/devilutionX/
=======
--------------------------------------------------------------------------------------------------
