# DCLXVI_X
Diablo mod

Updated from Devilution to DevilutionX...
=======
--------------------------------------------------------------------------------------------------
DCLXVI Beta Version Xb
=======

(You will need a copy of Diablo and Hellfire to use this)
=======

Diablo 1 Mod DCLXVI by G0PLY,
made using DevilutionX v1.41 by GalaXyHaXz and Devilution Team.
=======
--------------------------------------------------------------------------------------------------

Prebuilt Version only, for now...

Download DCLXVI.zip

The following files are not included in this download: 
DIABDAT.MPQ diabloui.dll SMACKW32.DLL STANDARD.snp Storm.dll (from Diablo)
hellfire.mpq hfmonk.mpq hfmusic.mpq hfvoice.mpq (from Hellfire)

drop the files listed above into the following location
({drive}:\Users\{username}\AppData\Roaming\daemonstrat\DCLXVI)
or goto File Explorer and type %AppData%

Digital verion of Diablo plus Hellfire can be purchased at www.gog.com

game options file is diablo.ini located in the %AppData% folder
devilutionx features work except refills, and globe data for non mana classes have been disabled,
this mod is intended to be used with Singleplayer Quests turned on but is not forced (although it might cause issues if not turned on)
--------------------------------------------------------------------------------------------------
DCLXVI Features: 
=======
Ironman-esk inspired Diablo mod
--------------------------------------------------------------------------------------------------
Added "Classes", class skills may only be used by other classes with scrolls,

Multiplayer mode only,

Weapons may have spells,

Players start with 100gp and no items,

Increased curse chances on items,

Removed most type restrictions on item prefix/suffix, 

Increased level cap (100, softcap currently 70), 

Reduced stat gain (3 per lv), 

Vitality capped depending on class,

Vitality elixer values set to equivilant of Full Health potion,

NPCs dont sell full potions,

Slight adjustment on starting stats,

Increased stat caps (primary stat still 250), 

Removed free refill of health and mana (leveling up and NPC visits),

Removed elixer potions from shops,

Gris sometimes sells oils in basic tab,

New Charging runes (witch sometimes sells),

New Max Charge runes (witch sometimes sells),

New Stat Exchange Uniques (12 rings, 6 amulets),

New Skeleton King room palette,

Removed accuracy, sharpness, hard and skill oils,

Removed extra charges prefix/suffix,

Increased monster health, 

Increases monsters per floor,

Modified weapon and armor requirements,

NPCs no longer repair or recharge items,

Must kill Diablo to advance difficulty,

Bard, Assassin and Barbarian have no mana,

Removed action time differences based on class type.

Class Abilities:
- Warrior:ItemRepair -
- Rogue:TrapDisarm -
- Sorcerer:ManaShield -
- Monk:Warp -
- Bard:Berserk -
- Barbarian:Rage -
- Paladin:Resurrect -
- Assassin:Infravision -
- Battlemage:Teleport -
- Kabbalist:Golem -
- Templar:Reflect -
- Witch:StaffRecharge -
- Psychokineticist:Telekinesis -
- Sage:Identify -
- Warlock:Magi -
- Traveler:TownPortal -
- Cleric:HealOther -

--------------------------------------------------------------------------------------------------
Using devilutionX-1.41
=======

For more information or more detailed instructions on installing. https://github.com/diasurgical/devilutionX/
=======
--------------------------------------------------------------------------------------------------
