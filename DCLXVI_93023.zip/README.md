# DCLXVI_X
A mod for Diablo 1 with Hellfire

DCLXVI v93023

=======

(You will need a copy of Diablo and Hellfire to use this)

=======

Diablo 1 Mod DCLXVI by G0PLY,
made using DevilutionX v1.5 by GalaXyHaXz and Devilution Team.

=======
--------------------------------------------------------------------------------------------------

DCLXVI: 
=======

Singleplayer Ironman-esk inspired Diablo mod,

... Good Luck.

--------------------------------------------------------------------------------------------------
To-do-list (/issues): Spell icons, Overhead buff icons, (Multiplayer)

Latest Updates:

9/30/23 -- This is the most current version...

--------------------------------------------------------------------------------------------------

Prebuilt Windows Version...

Download DCLXVI_93023.zip (Singleplayer only, has more features but less traditional style, has Bloodmage)

Download DCLXVI_6123.zip (Multiplayer, less features but more traditional style, no Bloodmage)

The following files are not included in this download: 
DIABDAT.MPQ diabloui.dll SMACKW32.DLL STANDARD.snp Storm.dll (from Diablo)
hellfire.mpq hfmonk.mpq hfmusic.mpq hfvoice.mpq (from Hellfire)

drop the files listed above into the following location
({drive}:\Users\{username}\AppData\Roaming\daemonstrat\DCLXVI)
or goto File Explorer and type %AppData%

Digital verion of Diablo plus Hellfire can be purchased at www.gog.com

game options file is diablo.ini located in the %AppData% folder,
health/mana orbs data has been disabled even when ON in options

--------------------------------------------------------------------------------------------------

Using devilutionX-1.5

download devilutionX v1.5 from
https://github.com/diasurgical/devilutionX/releases

=======

For more information or more detailed instructions on installing. https://github.com/diasurgical/devilutionX/
=======
--------------------------------------------------------------------------------------------------
