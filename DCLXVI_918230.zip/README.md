# DCLXVI_X
Diablo mod

Updated from Devilution to DevilutionX...

=======
--------------------------------------------------------------------------------------------------
DCLXVI Beta Version Xb_91823.0

=======

(You will need a copy of Diablo and Hellfire to use this)

=======

Diablo 1 Mod DCLXVI by G0PLY,
made using DevilutionX v1.41 by GalaXyHaXz and Devilution Team.

=======
--------------------------------------------------------------------------------------------------

Prebuilt Windows Version only, for now...

Download DCLXVI.zip

The following files are not included in this download: 
DIABDAT.MPQ diabloui.dll SMACKW32.DLL STANDARD.snp Storm.dll (from Diablo)
hellfire.mpq hfmonk.mpq hfmusic.mpq hfvoice.mpq (from Hellfire)

drop the files listed above into the following location
({drive}:\Users\{username}\AppData\Roaming\daemonstrat\DCLXVI)
or goto File Explorer and type %AppData%

Digital verion of Diablo plus Hellfire can be purchased at www.gog.com

game options file is diablo.ini located in the %AppData% folder,
health/mana orbs data has been disabled even when ON in options

--------------------------------------------------------------------------------------------------
DCLXVI: 
=======
Ironman-esk inspired Diablo mod
Normal difficulty has been tested and probably won't change, 
NM and Hell have not been fully tested

--------------------------------------------------------------------------------------------------
9/18/23 -- Manashield Fix -- Manashield no longer kicks players from the game,
;/, 

9/17/23 -- Moved Witch near town portals, removed mana cost of Bloodmagic,..
Healing, Heal Other, WitchBloodstar, Bonespirit, Mana from Blood and Bloodmagic removed from Bloodmagic effect (always require mana),

9/16/23 -- Fix for Bloodmagic, spells are no longer blocked by not having enough mana,

As of 6/18/23 this mod was updated with a bunch of changes that are not listed below...,
-added class books and increased spell menu tabs, secondary class abilities added to each class-

Added "Classes", class skills useable by other classes with scrolls and staves,

Multiplayer mode only,

Weapons may have spells,

Items with magic must be equipped to see what spell it has (no more Staff of Healing type names),

Players start with 1000gp and no items,

Increased curse chances on items,

Removed most type restrictions on item prefix/suffix, 

Increased level cap 100, 

Reduced stat gain (3 per lv, elixers needed to max stats), 

Vitality capped depending on class (starts at max),

Vitality elixer values are basically Full Health potion,

NPCs dont sell full potions,

Slight adjustment on starting stats,

Increased stat caps (primary stat still 250), 

Removed free refill of health and mana (leveling up and NPC visits),

Removed elixer potions from shops,

Gris sometimes sells oils in basic tab,

New Charging runes (witch sometimes sells),

New Max Charge runes (witch sometimes sells),

New Stat Exchange Uniques (6 rings, 12 amulets),

New Skeleton King room palette,

Removed accuracy, sharpness, hard and skill oils,

Removed extra charges prefix/suffix,

Increased monster health, 

Increased monsters per floor,

Modified weapon and armor requirements,

NPCs no longer repair or recharge items,

Must kill Diablo to advance difficulty,

Bard, Assassin and Barbarian have no mana,

Spell formulas changed (spells now scale with magic amount and spell level),

Witch spells cost a percentage (mana drains very fast),

Warlock spells cost double,

Sorcerer/Sage/Battlemage/Traveler spells cost half,

Kabbalists' Golem now scales based on player stats, magic amount, tohit and dmg,

Warlocks' Magi costs health and scales with player level (caster recieves full mana),

Bloodmages' Bloodmagic changes spell costs from mana to health also passively converts mana to refill health,

Bards' Berserk no longer requires a target,

Battlemages' Teleport allowed in town,

Templars' Reflect now does magic damage as well as physical (magic dmg scales based on, player level/stats/ac),

Templars' Reflect no longer protects against damage,

Witch StaffRecharge no longer reduces max charge count,

Warrior ItemRepair no longer reduces max durability,

Removed action time frame differences based on class type (time to cast or shoot bow ect..)..

Class Abilities:
=======
- Warrior : ItemRepair -
- Rogue : TrapDisarm -
- Sorcerer : ManaShield -
- Monk : Warp -
- Bard : Berserk -
- Barbarian : Rage -
- Paladin : Resurrect -
- Assassin : Infravision -
- Battlemage : Teleport -
- Kabbalist : Golem -
- Templar : Reflect -
- Witch : StaffRecharge -
- Sage : Identify -
- Warlock : Magi -
- Traveler : TownPortal -
- Cleric : HealOther -
- Bloodmage : Bloodmagic - 

New Uniques:
=======
- A2 Amulets
- Amulet : +50 Str, -50 Mag
- Amulet : +50 Str, -50 Dex
- Amulet : +50 Dex, -50 Mag
- Amulet : +50 Dex, -50 Str
- Amulet : +50 Mag, -50 Dex
- Amulet : +50 Mag, -50 Str

- A1 Amulets
- Amulet : +25 Str, -25 Mag
- Amulet : +25 Str, -25 Dex
- Amulet : +25 Dex, -25 Mag
- Amulet : +25 Dex, -25 Str
- Amulet : +25 Mag, -25 Dex
- Amulet : +25 Mag, -25 Str

- R1 Rings
- Ring : +25 Str, -25 Mag
- Ring : +25 Str, -25 Dex
- Ring : +25 Dex, -25 Mag
- Ring : +25 Dex, -25 Str
- Ring : +25 Mag, -25 Dex
- Ring : +25 Mag, -25 Str

Class Stats:
=======
Starting primary stats define the max.

Classes with 35 or 40 as primary starting stat,
- 40 start = 255 max,
- 35 start = 250 max,
- 30 start = NA,
- 25 start = 96 max,
- 20 start = 82 max,
- 15 start = 75 max,

Classes without 35 or 40 as primary starting stat,
- 30 start = 153 max,
- 25 start = 137 max,
- 20 start = 123 max,
- 15 start = 116 max,

Vitality is formulated based on starting stats...

Bloodmage health increases with magic stat,

--------------------------------------------------------------------------------------------------
Using devilutionX-1.41
=======

For more information or more detailed instructions on installing. https://github.com/diasurgical/devilutionX/
=======
--------------------------------------------------------------------------------------------------
