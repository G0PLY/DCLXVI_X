# DCLXVI_X
A mod for Diablo 1 with Hellfire

DCLXVI v92823

=======

(You will need a copy of Diablo and Hellfire to use this)

=======

Diablo 1 Mod DCLXVI by G0PLY,
made using DevilutionX v1.5 by GalaXyHaXz and Devilution Team.

=======
--------------------------------------------------------------------------------------------------

DCLXVI: 
=======

Singleplayer Ironman-esk inspired Diablo mod,

... Good Luck.

--------------------------------------------------------------------------------------------------
To-do-list (/issues): Spell icons, Overhead buff icons, (Theo, Magic Rock, Multiplayer)

Latest Updates:

9/28/23 -- reverted "hot" update, spells were missing target more than usual

9/27/23.2 -- hot update

9/27/23.1 -- traveler has town portal again instead of escape to town

9/27/23.0 -- classes revamped a bit (new abilities if old was multiplayer), drops on death disactivated, class spec books no longer drop/sell, golem shouldn't atk diablo

9/25/23 -- Health regen fixed, was broken on the following; Sorcerer, Sage, Bloodmage, Traveler, Witch, Warlock, Battlemage
added costs/lv reqs to a few overlooked items, remove testing ids from pre/suf on items

--------------------------------------------------------------------------------------------------

Prebuilt Windows Version...

Download DCLXVI_92823.zip (Singleplayer only, has more features but less traditional style, has Bloodmage)

Download DCLXVI_6123.zip (Multiplayer, less features but more traditional style, no Bloodmage)

The following files are not included in this download: 
DIABDAT.MPQ diabloui.dll SMACKW32.DLL STANDARD.snp Storm.dll (from Diablo)
hellfire.mpq hfmonk.mpq hfmusic.mpq hfvoice.mpq (from Hellfire)

drop the files listed above into the following location
({drive}:\Users\{username}\AppData\Roaming\daemonstrat\DCLXVI)
or goto File Explorer and type %AppData%

Digital verion of Diablo plus Hellfire can be purchased at www.gog.com

game options file is diablo.ini located in the %AppData% folder,
health/mana orbs data has been disabled even when ON in options

--------------------------------------------------------------------------------------------------

Using devilutionX-1.5

download devilutionX v1.5 from
https://github.com/diasurgical/devilutionX/releases

=======

For more information or more detailed instructions on installing. https://github.com/diasurgical/devilutionX/
=======
--------------------------------------------------------------------------------------------------
