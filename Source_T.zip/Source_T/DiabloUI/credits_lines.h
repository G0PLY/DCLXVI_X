#include <cstddef>

namespace devilution {

extern const char *const CreditLines[];
extern const std::size_t CreditLinesSize;

} // namespace devilution
