#pragma once

#include "utils/stdcompat/string_view.hpp"

void vita_start_text_input(devilution::string_view guide_text, devilution::string_view initial_text, unsigned max_length);
